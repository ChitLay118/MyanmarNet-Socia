import { View, Text, Pressable, StyleSheet, Dimensions } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '../ui/Avatar';
import { Post } from '../../services/postService';
import { theme } from '../../constants/theme';

interface PostCardProps {
  post: Post;
  onLike: (postId: string) => void;
  onComment?: (postId: string) => void;
  onShare?: (postId: string) => void;
}

export function PostCard({ post, onLike, onComment, onShare }: PostCardProps) {
  const timeAgo = getTimeAgo(post.timestamp);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Avatar source={post.userAvatar} size={40} />
        <View style={styles.headerInfo}>
          <Text style={styles.userName}>{post.userName}</Text>
          <Text style={styles.time}>{timeAgo}</Text>
        </View>
        <Ionicons name="ellipsis-horizontal" size={20} color={theme.colors.textSecondary} />
      </View>

      <Text style={styles.content}>{post.content}</Text>

      {post.images && post.images.length > 0 && (
        <Image
          source={{ uri: post.images[0] }}
          style={styles.image}
          contentFit="cover"
        />
      )}

      <View style={styles.stats}>
        <Text style={styles.statsText}>
          {post.likes} {post.likes === 1 ? 'like' : 'likes'}
        </Text>
        <View style={styles.statsRight}>
          <Text style={styles.statsText}>{post.comments} comments</Text>
          <Text style={styles.statsText}> · </Text>
          <Text style={styles.statsText}>{post.shares} shares</Text>
        </View>
      </View>

      <View style={styles.divider} />

      <View style={styles.actions}>
        <Pressable
          style={({ pressed }) => [styles.actionButton, pressed && styles.actionPressed]}
          onPress={() => onLike(post.id)}
        >
          <Ionicons
            name={post.isLiked ? 'heart' : 'heart-outline'}
            size={20}
            color={post.isLiked ? theme.colors.error : theme.colors.textSecondary}
          />
          <Text style={[styles.actionText, post.isLiked && styles.actionTextActive]}>
            Like
          </Text>
        </Pressable>

        <Pressable
          style={({ pressed }) => [styles.actionButton, pressed && styles.actionPressed]}
          onPress={() => onComment?.(post.id)}
        >
          <Ionicons name="chatbubble-outline" size={20} color={theme.colors.textSecondary} />
          <Text style={styles.actionText}>Comment</Text>
        </Pressable>

        <Pressable
          style={({ pressed }) => [styles.actionButton, pressed && styles.actionPressed]}
          onPress={() => onShare?.(post.id)}
        >
          <Ionicons name="arrow-redo-outline" size={20} color={theme.colors.textSecondary} />
          <Text style={styles.actionText}>Share</Text>
        </Pressable>
      </View>
    </View>
  );
}

function getTimeAgo(timestamp: number): string {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  return `${Math.floor(seconds / 86400)}d`;
}

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    backgroundColor: theme.colors.surface,
    marginBottom: theme.spacing.sm,
    paddingVertical: theme.spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
    marginBottom: theme.spacing.md,
  },
  headerInfo: {
    flex: 1,
    marginLeft: theme.spacing.sm,
  },
  userName: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  time: {
    fontSize: theme.fontSizes.xs,
    color: theme.colors.textSecondary,
    marginTop: 2,
    includeFontPadding: false,
  },
  content: {
    fontSize: theme.fontSizes.base,
    color: theme.colors.text,
    lineHeight: 20,
    paddingHorizontal: theme.spacing.lg,
    marginBottom: theme.spacing.md,
    includeFontPadding: false,
  },
  image: {
    width: width,
    height: width * 0.75,
    backgroundColor: theme.colors.borderLight,
    marginBottom: theme.spacing.sm,
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
    marginBottom: theme.spacing.sm,
  },
  statsRight: {
    flexDirection: 'row',
  },
  statsText: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    includeFontPadding: false,
  },
  divider: {
    height: 1,
    backgroundColor: theme.colors.borderLight,
    marginHorizontal: theme.spacing.lg,
    marginBottom: theme.spacing.sm,
  },
  actions: {
    flexDirection: 'row',
    paddingHorizontal: theme.spacing.sm,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.md,
  },
  actionPressed: {
    backgroundColor: theme.colors.surfaceHover,
  },
  actionText: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.xs,
    includeFontPadding: false,
  },
  actionTextActive: {
    color: theme.colors.error,
  },
});
