import { useState } from 'react';
import {
  View,
  Text,
  Modal,
  FlatList,
  TextInput,
  Pressable,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '../ui/Avatar';
import { useComments } from '../../hooks/useComments';
import { theme } from '../../constants/theme';
import { Comment } from '../../services/commentService';

interface CommentsModalProps {
  visible: boolean;
  postId: string;
  onClose: () => void;
}

function CommentItem({ comment, onLike }: { comment: Comment; onLike: () => void }) {
  const timeAgo = Math.floor((Date.now() - comment.timestamp) / 60000);
  const timeText = timeAgo < 60 ? `${timeAgo}m` : `${Math.floor(timeAgo / 60)}h`;

  return (
    <View style={styles.commentItem}>
      <Avatar source={comment.userAvatar} size={36} />
      <View style={styles.commentContent}>
        <View style={styles.commentBubble}>
          <Text style={styles.commentUserName}>{comment.userName}</Text>
          <Text style={styles.commentText}>{comment.content}</Text>
        </View>
        <View style={styles.commentActions}>
          <Text style={styles.commentTime}>{timeText}</Text>
          <Pressable onPress={onLike} style={styles.commentLike}>
            <Text style={styles.commentLikeText}>Like</Text>
            {comment.likes > 0 && (
              <Text style={styles.commentLikeCount}> · {comment.likes}</Text>
            )}
          </Pressable>
        </View>
      </View>
    </View>
  );
}

export function CommentsModal({ visible, postId, onClose }: CommentsModalProps) {
  const [inputText, setInputText] = useState('');
  const { comments, loading, submitting, handleAddComment, handleLikeComment } = useComments(postId);

  const onSubmit = async () => {
    if (!inputText.trim() || submitting) return;
    await handleAddComment(inputText);
    setInputText('');
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Comments</Text>
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={28} color={theme.colors.text} />
          </Pressable>
        </View>

        {loading ? (
          <View style={styles.loading}>
            <ActivityIndicator size="large" color={theme.colors.primary} />
          </View>
        ) : (
          <FlatList
            data={comments}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <CommentItem comment={item} onLike={() => handleLikeComment(item.id)} />
            )}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
          />
        )}

        <View style={styles.inputContainer}>
          <Avatar source="https://i.pravatar.cc/150?img=68" size={36} />
          <TextInput
            style={styles.input}
            placeholder="Write a comment..."
            placeholderTextColor={theme.colors.textTertiary}
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={500}
          />
          <Pressable
            onPress={onSubmit}
            disabled={!inputText.trim() || submitting}
            style={styles.sendButton}
          >
            <Ionicons
              name="send"
              size={24}
              color={inputText.trim() && !submitting ? theme.colors.primary : theme.colors.textTertiary}
            />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderLight,
  },
  title: {
    fontSize: theme.fontSizes.xl,
    fontWeight: '600',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  closeButton: {
    padding: theme.spacing.xs,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    padding: theme.spacing.lg,
  },
  commentItem: {
    flexDirection: 'row',
    marginBottom: theme.spacing.lg,
  },
  commentContent: {
    flex: 1,
    marginLeft: theme.spacing.sm,
  },
  commentBubble: {
    backgroundColor: theme.colors.background,
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.lg,
  },
  commentUserName: {
    fontSize: theme.fontSizes.sm,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
    includeFontPadding: false,
  },
  commentText: {
    fontSize: theme.fontSizes.base,
    color: theme.colors.text,
    includeFontPadding: false,
  },
  commentActions: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: theme.spacing.xs,
    marginLeft: theme.spacing.md,
    gap: theme.spacing.md,
  },
  commentTime: {
    fontSize: theme.fontSizes.xs,
    color: theme.colors.textSecondary,
    includeFontPadding: false,
  },
  commentLike: {
    flexDirection: 'row',
  },
  commentLikeText: {
    fontSize: theme.fontSizes.xs,
    fontWeight: '600',
    color: theme.colors.textSecondary,
    includeFontPadding: false,
  },
  commentLikeCount: {
    fontSize: theme.fontSizes.xs,
    color: theme.colors.textSecondary,
    includeFontPadding: false,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.borderLight,
    backgroundColor: theme.colors.surface,
  },
  input: {
    flex: 1,
    fontSize: theme.fontSizes.base,
    color: theme.colors.text,
    marginHorizontal: theme.spacing.sm,
    maxHeight: 100,
    includeFontPadding: false,
  },
  sendButton: {
    padding: theme.spacing.xs,
  },
});
