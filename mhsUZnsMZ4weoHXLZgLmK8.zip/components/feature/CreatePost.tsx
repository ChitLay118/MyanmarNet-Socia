import { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Modal, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '../ui/Avatar';
import { Button } from '../ui/Button';
import { theme } from '../../constants/theme';

interface CreatePostProps {
  visible: boolean;
  onClose: () => void;
  onSubmit: (content: string) => Promise<void>;
}

export function CreatePost({ visible, onClose, onSubmit }: CreatePostProps) {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!content.trim()) return;
    
    setLoading(true);
    await onSubmit(content);
    setLoading(false);
    setContent('');
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={false}
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <View style={styles.header}>
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={28} color={theme.colors.text} />
          </Pressable>
          <Text style={styles.title}>Create Post</Text>
          <Button
            title="Post"
            onPress={handleSubmit}
            size="small"
            disabled={!content.trim()}
            loading={loading}
          />
        </View>

        <View style={styles.content}>
          <View style={styles.userInfo}>
            <Avatar source="https://i.pravatar.cc/150?img=68" size={40} />
            <Text style={styles.userName}>You</Text>
          </View>

          <TextInput
            style={styles.input}
            placeholder="What's on your mind?"
            placeholderTextColor={theme.colors.textTertiary}
            value={content}
            onChangeText={setContent}
            multiline
            autoFocus
            textAlignVertical="top"
          />

          <View style={styles.options}>
            <Pressable 
              style={styles.optionButton}
              onPress={async () => {
                const result = await ImagePicker.launchImageLibraryAsync({
                  mediaTypes: ImagePicker.MediaTypeOptions.All,
                  allowsEditing: true,
                  quality: 1,
                });
                if (!result.canceled) {
                  Alert.alert('Success', 'Photo selected! (Feature coming soon)');
                }
              }}
            >
              <Ionicons name="image-outline" size={24} color={theme.colors.success} />
              <Text style={styles.optionText}>Photo/Video</Text>
            </Pressable>
            
            <Pressable 
              style={styles.optionButton}
              onPress={() => Alert.alert('Coming Soon', 'Feeling/Activity feature will be available soon!')}
            >
              <Ionicons name="happy-outline" size={24} color={theme.colors.warning} />
              <Text style={styles.optionText}>Feeling/Activity</Text>
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderLight,
  },
  closeButton: {
    padding: theme.spacing.xs,
  },
  title: {
    fontSize: theme.fontSizes.xl,
    fontWeight: '600',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  content: {
    flex: 1,
    padding: theme.spacing.lg,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.lg,
  },
  userName: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    includeFontPadding: false,
  },
  input: {
    flex: 1,
    fontSize: theme.fontSizes.lg,
    color: theme.colors.text,
    includeFontPadding: false,
  },
  options: {
    borderTopWidth: 1,
    borderTopColor: theme.colors.borderLight,
    paddingTop: theme.spacing.lg,
  },
  optionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
  },
  optionText: {
    fontSize: theme.fontSizes.base,
    color: theme.colors.text,
    marginLeft: theme.spacing.md,
    includeFontPadding: false,
  },
});
