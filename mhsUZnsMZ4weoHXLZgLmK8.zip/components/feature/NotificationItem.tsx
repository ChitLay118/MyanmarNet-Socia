import { View, Text, Pressable, StyleSheet } from 'react-native';
import { Avatar } from '../ui/Avatar';
import { Notification } from '../../services/notificationService';
import { theme } from '../../constants/theme';

interface NotificationItemProps {
  notification: Notification;
  onPress: () => void;
}

export function NotificationItem({ notification, onPress }: NotificationItemProps) {
  const timeAgo = getTimeAgo(notification.timestamp);
  
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.container,
        !notification.isRead && styles.unread,
        pressed && styles.pressed,
      ]}
    >
      <Avatar source={notification.userAvatar} size={56} />
      
      <View style={styles.content}>
        <Text style={styles.text}>
          <Text style={styles.userName}>{notification.userName}</Text>
          {' '}
          <Text style={styles.action}>{notification.content}</Text>
        </Text>
        <Text style={styles.time}>{timeAgo}</Text>
      </View>
      
      {!notification.isRead && <View style={styles.badge} />}
    </Pressable>
  );
}

function getTimeAgo(timestamp: number): string {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  return `${Math.floor(seconds / 604800)}w ago`;
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
    backgroundColor: theme.colors.surface,
  },
  unread: {
    backgroundColor: '#EBF5FF',
  },
  pressed: {
    backgroundColor: theme.colors.surfaceHover,
  },
  content: {
    flex: 1,
    marginLeft: theme.spacing.md,
  },
  text: {
    fontSize: theme.fontSizes.base,
    lineHeight: 20,
    includeFontPadding: false,
  },
  userName: {
    fontWeight: '600',
    color: theme.colors.text,
  },
  action: {
    color: theme.colors.textSecondary,
  },
  time: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    includeFontPadding: false,
  },
  badge: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: theme.colors.primary,
  },
});
