import { View, StyleSheet } from 'react-native';
import { Image } from 'expo-image';
import { theme } from '../../constants/theme';

interface AvatarProps {
  source: string;
  size?: number;
  showOnline?: boolean;
}

export function Avatar({ source, size = 40, showOnline = false }: AvatarProps) {
  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Image
        source={{ uri: source }}
        style={[styles.image, { width: size, height: size, borderRadius: size / 2 }]}
        contentFit="cover"
      />
      {showOnline && (
        <View style={[
          styles.onlineIndicator,
          { 
            width: size * 0.3,
            height: size * 0.3,
            borderRadius: size * 0.15,
            borderWidth: size * 0.06,
          }
        ]} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
  image: {
    backgroundColor: theme.colors.borderLight,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: theme.colors.online,
    borderColor: theme.colors.surface,
  },
});
