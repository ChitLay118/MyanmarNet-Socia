export const theme = {
  colors: {
    primary: '#2563EB',       // Facebook-style blue
    primaryDark: '#1D4ED8',
    primaryLight: '#3B82F6',
    
    background: '#F0F2F5',
    surface: '#FFFFFF',
    surfaceHover: '#F7F8FA',
    
    border: '#CED0D4',
    borderLight: '#E4E6EB',
    
    text: '#050505',
    textSecondary: '#65676B',
    textTertiary: '#8A8D91',
    
    success: '#42B72A',
    error: '#F02849',
    warning: '#F7B928',
    
    online: '#42B72A',
    overlay: 'rgba(0, 0, 0, 0.4)',
  },
  
  fonts: {
    regular: 'System',
    medium: 'System',
    semibold: 'System',
    bold: 'System',
  },
  
  fontSizes: {
    xs: 12,
    sm: 13,
    base: 14,
    md: 15,
    lg: 17,
    xl: 20,
    xxl: 24,
    xxxl: 28,
  },
  
  spacing: {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    xxl: 24,
    xxxl: 32,
  },
  
  borderRadius: {
    sm: 6,
    md: 8,
    lg: 12,
    full: 9999,
  },
  
  shadows: {
    sm: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 2,
      elevation: 2,
    },
    md: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    },
  },
};

export type Theme = typeof theme;
