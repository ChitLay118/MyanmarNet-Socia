import { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  Pressable,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '../../components';
import { getMessages, sendMessage, Message } from '../../services/messageService';
import { theme } from '../../constants/theme';

export default function ChatScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const flatListRef = useRef<FlatList>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');

  useEffect(() => {
    loadMessages();
  }, [id]);

  const loadMessages = async () => {
    if (!id) return;
    const data = await getMessages(id);
    setMessages(data);
  };

  const handleSend = async () => {
    if (!inputText.trim() || !id) return;

    const newMessage = await sendMessage(id, inputText);
    setMessages(prev => [...prev, newMessage]);
    setInputText('');
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
      keyboardVerticalOffset={insets.top}
    >
      <View style={[styles.header, { paddingTop: insets.top }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={theme.colors.text} />
        </Pressable>
        <Avatar source="https://i.pravatar.cc/150?img=12" size={40} showOnline />
        <Text style={styles.headerTitle}>Aung Kyaw</Text>
        <Pressable style={styles.iconButton}>
          <Ionicons name="call-outline" size={24} color={theme.colors.text} />
        </Pressable>
        <Pressable style={styles.iconButton}>
          <Ionicons name="videocam-outline" size={24} color={theme.colors.text} />
        </Pressable>
      </View>

      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={[styles.messageContainer, item.isOwn && styles.ownMessageContainer]}>
            {!item.isOwn && (
              <Avatar source="https://i.pravatar.cc/150?img=12" size={32} />
            )}
            <View style={[styles.messageBubble, item.isOwn && styles.ownMessageBubble]}>
              <Text style={[styles.messageText, item.isOwn && styles.ownMessageText]}>
                {item.content}
              </Text>
              <Text style={[styles.messageTime, item.isOwn && styles.ownMessageTime]}>
                {formatTime(item.timestamp)}
              </Text>
            </View>
          </View>
        )}
        contentContainerStyle={styles.messagesList}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
      />

      <View style={styles.inputContainer}>
        <Pressable style={styles.attachButton}>
          <Ionicons name="add-circle" size={28} color={theme.colors.primary} />
        </Pressable>
        <TextInput
          style={styles.input}
          placeholder="Type a message..."
          placeholderTextColor={theme.colors.textTertiary}
          value={inputText}
          onChangeText={setInputText}
          multiline
          maxLength={1000}
        />
        <Pressable
          onPress={handleSend}
          disabled={!inputText.trim()}
          style={styles.sendButton}
        >
          <Ionicons
            name="send"
            size={24}
            color={inputText.trim() ? theme.colors.primary : theme.colors.textTertiary}
          />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
    paddingBottom: theme.spacing.md,
    backgroundColor: theme.colors.surface,
    ...theme.shadows.sm,
  },
  backButton: {
    marginRight: theme.spacing.sm,
  },
  headerTitle: {
    flex: 1,
    fontSize: theme.fontSizes.lg,
    fontWeight: '600',
    color: theme.colors.text,
    marginLeft: theme.spacing.sm,
    includeFontPadding: false,
  },
  iconButton: {
    padding: theme.spacing.xs,
    marginLeft: theme.spacing.sm,
  },
  messagesList: {
    padding: theme.spacing.lg,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: theme.spacing.md,
    alignItems: 'flex-end',
  },
  ownMessageContainer: {
    justifyContent: 'flex-end',
  },
  messageBubble: {
    maxWidth: '70%',
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.lg,
    marginLeft: theme.spacing.sm,
  },
  ownMessageBubble: {
    backgroundColor: theme.colors.primary,
    marginLeft: 0,
  },
  messageText: {
    fontSize: theme.fontSizes.base,
    color: theme.colors.text,
    includeFontPadding: false,
  },
  ownMessageText: {
    color: theme.colors.surface,
  },
  messageTime: {
    fontSize: theme.fontSizes.xs,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    includeFontPadding: false,
  },
  ownMessageTime: {
    color: theme.colors.surface,
    opacity: 0.8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    backgroundColor: theme.colors.surface,
    borderTopWidth: 1,
    borderTopColor: theme.colors.borderLight,
  },
  attachButton: {
    marginRight: theme.spacing.sm,
  },
  input: {
    flex: 1,
    fontSize: theme.fontSizes.base,
    color: theme.colors.text,
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.full,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    maxHeight: 100,
    includeFontPadding: false,
  },
  sendButton: {
    marginLeft: theme.spacing.sm,
    padding: theme.spacing.xs,
  },
});
