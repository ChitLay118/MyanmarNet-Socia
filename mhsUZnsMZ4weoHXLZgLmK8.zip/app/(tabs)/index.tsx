import { useState } from 'react';
import { View, Text, FlatList, StyleSheet, Pressable, Platform, Share } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, PostCard, CreatePost } from '../../components';
import { CommentsModal } from '../../components/feature/CommentsModal';
import { usePosts } from '../../hooks/usePosts';
import { theme } from '../../constants/theme';

export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { posts, loading, refreshing, handleLike, handleCreatePost, handleRefresh } = usePosts();
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.logo}>Myanmar Net</Text>
        <View style={styles.headerActions}>
          <Pressable style={styles.iconButton} onPress={() => router.push('/search')}>
            <Ionicons name="search" size={24} color={theme.colors.text} />
          </Pressable>
          <Pressable style={styles.iconButton} onPress={() => router.push('/messages')}>
            <Ionicons name="chatbubbles" size={24} color={theme.colors.text} />
          </Pressable>
        </View>
      </View>

      <FlatList
        data={posts}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <PostCard
            post={item}
            onLike={handleLike}
            onComment={() => setSelectedPostId(item.id)}
            onShare={() => {
              Share.share({
                message: `${item.userName}: ${item.content}`,
                title: 'Share Post',
              });
            }}
          />
        )}
        ListHeaderComponent={
          <Pressable
            style={styles.createPostTrigger}
            onPress={() => setShowCreatePost(true)}
          >
            <Avatar source="https://i.pravatar.cc/150?img=68" size={40} />
            <Text style={styles.createPostText}>What's on your mind?</Text>
          </Pressable>
        }
        contentContainerStyle={styles.listContent}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        showsVerticalScrollIndicator={false}
      />

      <CreatePost
        visible={showCreatePost}
        onClose={() => setShowCreatePost(false)}
        onSubmit={handleCreatePost}
      />

      {selectedPostId && (
        <CommentsModal
          visible={selectedPostId !== null}
          postId={selectedPostId}
          onClose={() => setSelectedPostId(null)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    backgroundColor: theme.colors.surface,
    ...theme.shadows.sm,
  },
  logo: {
    fontSize: theme.fontSizes.xxl,
    fontWeight: '700',
    color: theme.colors.primary,
    includeFontPadding: false,
  },
  headerActions: {
    flexDirection: 'row',
    gap: theme.spacing.sm,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.colors.surfaceHover,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingBottom: theme.spacing.md,
  },
  createPostTrigger: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.sm,
  },
  createPostText: {
    flex: 1,
    fontSize: theme.fontSizes.md,
    color: theme.colors.textTertiary,
    marginLeft: theme.spacing.sm,
    includeFontPadding: false,
  },
});
