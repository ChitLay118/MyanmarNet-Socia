import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '../../components';
import { theme } from '../../constants/theme';

interface MenuItemProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  iconColor?: string;
  onPress?: () => void;
}

function MenuItem({ icon, title, iconColor = theme.colors.text, onPress }: MenuItemProps) {
  return (
    <Pressable
      style={({ pressed }) => [styles.menuItem, pressed && styles.menuItemPressed]}
      onPress={onPress}
    >
      <View style={[styles.iconContainer, { backgroundColor: iconColor + '20' }]}>
        <Ionicons name={icon} size={24} color={iconColor} />
      </View>
      <Text style={styles.menuText}>{title}</Text>
      <Ionicons name="chevron-forward" size={20} color={theme.colors.textSecondary} />
    </Pressable>
  );
}

export default function MenuScreen() {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Menu</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <Pressable style={styles.profileSection}>
          <Avatar source="https://i.pravatar.cc/150?img=68" size={64} />
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>Your Name</Text>
            <Text style={styles.profileAction}>See your profile</Text>
          </View>
        </Pressable>

        <View style={styles.section}>
          <MenuItem icon="settings-outline" title="Settings & Privacy" />
          <MenuItem icon="help-circle-outline" title="Help & Support" />
          <MenuItem icon="moon-outline" title="Dark Mode" />
        </View>

        <View style={styles.section}>
          <MenuItem icon="people-outline" title="Groups" iconColor={theme.colors.primary} />
          <MenuItem icon="bookmarks-outline" title="Saved" iconColor={theme.colors.success} />
          <MenuItem icon="videocam-outline" title="Videos" iconColor={theme.colors.error} />
          <MenuItem icon="calendar-outline" title="Events" iconColor={theme.colors.warning} />
        </View>

        <View style={styles.section}>
          <MenuItem icon="shield-checkmark-outline" title="Privacy Checkup" />
          <MenuItem icon="information-circle-outline" title="About" />
          <MenuItem icon="log-out-outline" title="Log Out" />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    backgroundColor: theme.colors.surface,
    ...theme.shadows.sm,
  },
  title: {
    fontSize: theme.fontSizes.xxl,
    fontWeight: '700',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.lg,
    marginTop: theme.spacing.sm,
    marginBottom: theme.spacing.sm,
  },
  profileInfo: {
    flex: 1,
    marginLeft: theme.spacing.md,
  },
  profileName: {
    fontSize: theme.fontSizes.lg,
    fontWeight: '600',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  profileAction: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    includeFontPadding: false,
  },
  section: {
    backgroundColor: theme.colors.surface,
    marginBottom: theme.spacing.sm,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderLight,
  },
  menuItemPressed: {
    backgroundColor: theme.colors.surfaceHover,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: theme.spacing.md,
  },
  menuText: {
    flex: 1,
    fontSize: theme.fontSizes.md,
    fontWeight: '500',
    color: theme.colors.text,
    includeFontPadding: false,
  },
});
