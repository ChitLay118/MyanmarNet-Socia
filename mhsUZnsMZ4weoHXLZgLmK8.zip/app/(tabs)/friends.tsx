import { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, Pressable, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, Button } from '../../components';
import { getFriends, getSuggestedFriends, getFriendRequests, acceptFriendRequest, sendFriendRequest, User, FriendRequest } from '../../services/userService';
import { theme } from '../../constants/theme';

type Tab = 'suggestions' | 'friends' | 'requests';

export default function FriendsScreen() {
  const insets = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState<Tab>('suggestions');
  const [friends, setFriends] = useState<User[]>([]);
  const [suggestions, setSuggestions] = useState<User[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [friendsData, suggestionsData, requestsData] = await Promise.all([
        getFriends(),
        getSuggestedFriends(),
        getFriendRequests(),
      ]);
      setFriends(friendsData);
      setSuggestions(suggestionsData);
      setRequests(requestsData);
    } catch (error) {
      console.error('Failed to load friends data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptRequest = async (requestId: string) => {
    await acceptFriendRequest(requestId);
    loadData();
  };

  const handleSendRequest = async (userId: string) => {
    await sendFriendRequest(userId);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Friends</Text>
      </View>

      <View style={styles.tabs}>
        <Pressable
          style={[styles.tab, activeTab === 'suggestions' && styles.tabActive]}
          onPress={() => setActiveTab('suggestions')}
        >
          <Text style={[styles.tabText, activeTab === 'suggestions' && styles.tabTextActive]}>
            Suggestions
          </Text>
        </Pressable>
        <Pressable
          style={[styles.tab, activeTab === 'friends' && styles.tabActive]}
          onPress={() => setActiveTab('friends')}
        >
          <Text style={[styles.tabText, activeTab === 'friends' && styles.tabTextActive]}>
            Your Friends
          </Text>
        </Pressable>
        <Pressable
          style={[styles.tab, activeTab === 'requests' && styles.tabActive]}
          onPress={() => setActiveTab('requests')}
        >
          <Text style={[styles.tabText, activeTab === 'requests' && styles.tabTextActive]}>
            Requests {requests.length > 0 && `(${requests.length})`}
          </Text>
        </Pressable>
      </View>

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
        </View>
      ) : (
        <>
          {activeTab === 'suggestions' && (
            <FlatList
              data={suggestions}
              keyExtractor={item => item.id}
              renderItem={({ item }) => (
                <View style={styles.userCard}>
                  <Avatar source={item.avatar} size={80} />
                  <Text style={styles.name}>{item.name}</Text>
                  {item.bio && <Text style={styles.bio}>{item.bio}</Text>}
                  <Text style={styles.mutualFriends}>{item.friendCount} friends</Text>
                  <Button
                    title="Add Friend"
                    onPress={() => handleSendRequest(item.id)}
                    variant="primary"
                    size="medium"
                  />
                </View>
              )}
              numColumns={2}
              columnWrapperStyle={styles.row}
              contentContainerStyle={styles.listContent}
              showsVerticalScrollIndicator={false}
            />
          )}

          {activeTab === 'friends' && (
            <FlatList
              data={friends}
              keyExtractor={item => item.id}
              renderItem={({ item }) => (
                <Pressable style={styles.friendItem}>
                  <Avatar source={item.avatar} size={56} showOnline={item.isOnline} />
                  <View style={styles.friendInfo}>
                    <Text style={styles.friendName}>{item.name}</Text>
                    {item.bio && <Text style={styles.friendBio}>{item.bio}</Text>}
                  </View>
                </Pressable>
              )}
              contentContainerStyle={styles.listContent}
              showsVerticalScrollIndicator={false}
            />
          )}

          {activeTab === 'requests' && (
            <FlatList
              data={requests}
              keyExtractor={item => item.id}
              renderItem={({ item }) => (
                <View style={styles.requestItem}>
                  <Avatar source={item.userAvatar} size={56} />
                  <View style={styles.requestInfo}>
                    <Text style={styles.requestName}>{item.userName}</Text>
                    <Text style={styles.mutualFriends}>{item.mutualFriends} mutual friends</Text>
                    <View style={styles.requestActions}>
                      <Button
                        title="Confirm"
                        onPress={() => handleAcceptRequest(item.id)}
                        variant="primary"
                        size="small"
                        style={styles.requestButton}
                      />
                      <Button
                        title="Delete"
                        onPress={() => {}}
                        variant="secondary"
                        size="small"
                        style={styles.requestButton}
                      />
                    </View>
                  </View>
                </View>
              )}
              contentContainerStyle={styles.listContent}
              showsVerticalScrollIndicator={false}
            />
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    backgroundColor: theme.colors.surface,
    ...theme.shadows.sm,
  },
  title: {
    fontSize: theme.fontSizes.xxl,
    fontWeight: '700',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: theme.colors.surface,
    paddingHorizontal: theme.spacing.sm,
    marginBottom: theme.spacing.sm,
  },
  tab: {
    paddingVertical: theme.spacing.md,
    paddingHorizontal: theme.spacing.lg,
    borderBottomWidth: 3,
    borderBottomColor: 'transparent',
  },
  tabActive: {
    borderBottomColor: theme.colors.primary,
  },
  tabText: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.textSecondary,
    includeFontPadding: false,
  },
  tabTextActive: {
    color: theme.colors.primary,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    padding: theme.spacing.sm,
  },
  row: {
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.sm,
  },
  userCard: {
    width: '48%',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.lg,
    alignItems: 'center',
    marginBottom: theme.spacing.md,
    ...theme.shadows.sm,
  },
  name: {
    fontSize: theme.fontSizes.md,
    fontWeight: '600',
    color: theme.colors.text,
    marginTop: theme.spacing.sm,
    includeFontPadding: false,
  },
  bio: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginTop: theme.spacing.xs,
    includeFontPadding: false,
  },
  mutualFriends: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    marginBottom: theme.spacing.md,
    includeFontPadding: false,
  },
  friendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.sm,
    borderRadius: theme.borderRadius.md,
  },
  friendInfo: {
    flex: 1,
    marginLeft: theme.spacing.md,
  },
  friendName: {
    fontSize: theme.fontSizes.md,
    fontWeight: '600',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  friendBio: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    includeFontPadding: false,
  },
  requestItem: {
    flexDirection: 'row',
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.lg,
    marginBottom: theme.spacing.sm,
    borderRadius: theme.borderRadius.md,
  },
  requestInfo: {
    flex: 1,
    marginLeft: theme.spacing.md,
  },
  requestName: {
    fontSize: theme.fontSizes.md,
    fontWeight: '600',
    color: theme.colors.text,
    includeFontPadding: false,
  },
  requestActions: {
    flexDirection: 'row',
    marginTop: theme.spacing.md,
    gap: theme.spacing.sm,
  },
  requestButton: {
    flex: 1,
  },
});
