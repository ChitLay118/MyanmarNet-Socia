import { useState, useEffect, useCallback } from 'react';
import { getPosts, likePost, createPost, Post } from '../services/postService';

export function usePosts() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadPosts = useCallback(async () => {
    try {
      const data = await getPosts();
      setPosts(data);
    } catch (error) {
      console.error('Failed to load posts:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  const handleLike = useCallback(async (postId: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          isLiked: !post.isLiked,
          likes: post.isLiked ? post.likes - 1 : post.likes + 1,
        };
      }
      return post;
    }));
    
    try {
      await likePost(postId);
    } catch (error) {
      console.error('Failed to like post:', error);
      loadPosts();
    }
  }, [loadPosts]);

  const handleCreatePost = useCallback(async (content: string, images?: string[]) => {
    try {
      const newPost = await createPost(content, images);
      setPosts(prev => [newPost, ...prev]);
      return true;
    } catch (error) {
      console.error('Failed to create post:', error);
      return false;
    }
  }, []);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    loadPosts();
  }, [loadPosts]);

  return {
    posts,
    loading,
    refreshing,
    handleLike,
    handleCreatePost,
    handleRefresh,
  };
}
