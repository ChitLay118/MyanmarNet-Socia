export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'friend_request' | 'friend_accept' | 'mention';
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  postId?: string;
  timestamp: number;
  isRead: boolean;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: 'n1',
    type: 'like',
    userId: 'u1',
    userName: 'Aung Kyaw',
    userAvatar: 'https://i.pravatar.cc/150?img=12',
    content: 'liked your post',
    postId: '2',
    timestamp: Date.now() - 1800000,
    isRead: false,
  },
  {
    id: 'n2',
    type: 'comment',
    userId: 'u2',
    userName: 'Thida San',
    userAvatar: 'https://i.pravatar.cc/150?img=45',
    content: 'commented on your post',
    postId: '2',
    timestamp: Date.now() - 3600000,
    isRead: false,
  },
  {
    id: 'n3',
    type: 'friend_request',
    userId: 'u5',
    userName: 'Htet Aung',
    userAvatar: 'https://i.pravatar.cc/150?img=56',
    content: 'sent you a friend request',
    timestamp: Date.now() - 7200000,
    isRead: true,
  },
];

export async function getNotifications(): Promise<Notification[]> {
  await new Promise(resolve => setTimeout(resolve, 400));
  return MOCK_NOTIFICATIONS;
}

export async function markAsRead(notificationId: string): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 200));
  const notification = MOCK_NOTIFICATIONS.find(n => n.id === notificationId);
  if (notification) {
    notification.isRead = true;
  }
}

export function getUnreadCount(): number {
  return MOCK_NOTIFICATIONS.filter(n => !n.isRead).length;
}
