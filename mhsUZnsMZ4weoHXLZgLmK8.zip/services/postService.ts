export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  images?: string[];
  video?: string;
  likes: number;
  comments: number;
  shares: number;
  timestamp: number;
  isLiked: boolean;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  likes: number;
  timestamp: number;
}

const MOCK_POSTS: Post[] = [
  {
    id: '1',
    userId: 'u1',
    userName: 'Aung Kyaw',
    userAvatar: 'https://i.pravatar.cc/150?img=12',
    content: 'မင်္ဂလာပါ Myanmar Net မှ အားလုံးကို ကြိုဆိုပါတယ်! 🎉',
    likes: 45,
    comments: 12,
    shares: 3,
    timestamp: Date.now() - 3600000,
    isLiked: false,
  },
  {
    id: '2',
    userId: 'u2',
    userName: 'Thida San',
    userAvatar: 'https://i.pravatar.cc/150?img=45',
    content: 'ရန်ကုန်မှ နေဝင်ချိန် ရှုခင်း 🌅',
    images: ['https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800'],
    likes: 128,
    comments: 24,
    shares: 8,
    timestamp: Date.now() - 7200000,
    isLiked: true,
  },
  {
    id: '3',
    userId: 'u3',
    userName: 'Ko Zaw',
    userAvatar: 'https://i.pravatar.cc/150?img=33',
    content: 'ဒီနေ့ စာသင်ခန်းမှာ သင်ယူခဲ့တာတွေ အရမ်းကောင်းတယ်။ Programming အရမ်းစိတ်ဝင်စားဖို့ကောင်းပါတယ် 💻',
    likes: 67,
    comments: 15,
    shares: 5,
    timestamp: Date.now() - 14400000,
    isLiked: false,
  },
];

export async function getPosts(): Promise<Post[]> {
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_POSTS;
}

export async function likePost(postId: string): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const post = MOCK_POSTS.find(p => p.id === postId);
  if (post) {
    post.isLiked = !post.isLiked;
    post.likes += post.isLiked ? 1 : -1;
  }
}

export async function createPost(content: string, images?: string[]): Promise<Post> {
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const newPost: Post = {
    id: Date.now().toString(),
    userId: 'current',
    userName: 'You',
    userAvatar: 'https://i.pravatar.cc/150?img=68',
    content,
    images,
    likes: 0,
    comments: 0,
    shares: 0,
    timestamp: Date.now(),
    isLiked: false,
  };
  
  MOCK_POSTS.unshift(newPost);
  return newPost;
}
