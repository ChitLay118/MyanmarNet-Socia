export interface User {
  id: string;
  name: string;
  avatar: string;
  bio?: string;
  friendCount: number;
  isOnline: boolean;
  isFriend: boolean;
}

export interface FriendRequest {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  mutualFriends: number;
  timestamp: number;
}

const MOCK_USERS: User[] = [
  {
    id: 'u1',
    name: 'Aung Kyaw',
    avatar: 'https://i.pravatar.cc/150?img=12',
    bio: 'Software Developer from Yangon',
    friendCount: 342,
    isOnline: true,
    isFriend: true,
  },
  {
    id: 'u2',
    name: 'Thida San',
    avatar: 'https://i.pravatar.cc/150?img=45',
    bio: 'Photography enthusiast 📸',
    friendCount: 567,
    isOnline: false,
    isFriend: true,
  },
  {
    id: 'u4',
    name: 'May Thu',
    avatar: 'https://i.pravatar.cc/150?img=23',
    bio: 'Travel blogger',
    friendCount: 234,
    isOnline: true,
    isFriend: false,
  },
];

const MOCK_REQUESTS: FriendRequest[] = [
  {
    id: 'r1',
    userId: 'u5',
    userName: 'Htet Aung',
    userAvatar: 'https://i.pravatar.cc/150?img=56',
    mutualFriends: 12,
    timestamp: Date.now() - 3600000,
  },
  {
    id: 'r2',
    userId: 'u6',
    userName: 'Su Mon',
    userAvatar: 'https://i.pravatar.cc/150?img=47',
    mutualFriends: 5,
    timestamp: Date.now() - 7200000,
  },
];

export async function getFriends(): Promise<User[]> {
  await new Promise(resolve => setTimeout(resolve, 400));
  return MOCK_USERS.filter(u => u.isFriend);
}

export async function getSuggestedFriends(): Promise<User[]> {
  await new Promise(resolve => setTimeout(resolve, 400));
  return MOCK_USERS.filter(u => !u.isFriend);
}

export async function getFriendRequests(): Promise<FriendRequest[]> {
  await new Promise(resolve => setTimeout(resolve, 400));
  return MOCK_REQUESTS;
}

export async function acceptFriendRequest(requestId: string): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const index = MOCK_REQUESTS.findIndex(r => r.id === requestId);
  if (index !== -1) {
    MOCK_REQUESTS.splice(index, 1);
  }
}

export async function sendFriendRequest(userId: string): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 300));
}
