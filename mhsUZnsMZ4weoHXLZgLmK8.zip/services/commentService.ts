export interface Comment {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  timestamp: number;
  likes: number;
}

const MOCK_COMMENTS: Comment[] = [
  {
    id: 'c1',
    postId: 'p1',
    userId: 'u1',
    userName: 'Aung Kyaw',
    userAvatar: 'https://i.pravatar.cc/150?img=12',
    content: 'Great post! 👍',
    timestamp: Date.now() - 1800000,
    likes: 5,
  },
  {
    id: 'c2',
    postId: 'p1',
    userId: 'u2',
    userName: 'Thida San',
    userAvatar: 'https://i.pravatar.cc/150?img=45',
    content: 'Totally agree with this!',
    timestamp: Date.now() - 900000,
    likes: 2,
  },
];

export async function getComments(postId: string): Promise<Comment[]> {
  await new Promise(resolve => setTimeout(resolve, 300));
  return MOCK_COMMENTS.filter(c => c.postId === postId);
}

export async function addComment(postId: string, content: string): Promise<Comment> {
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const newComment: Comment = {
    id: `c${Date.now()}`,
    postId,
    userId: 'current',
    userName: 'You',
    userAvatar: 'https://i.pravatar.cc/150?img=68',
    content,
    timestamp: Date.now(),
    likes: 0,
  };
  
  MOCK_COMMENTS.push(newComment);
  return newComment;
}

export async function likeComment(commentId: string): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 200));
  const comment = MOCK_COMMENTS.find(c => c.id === commentId);
  if (comment) {
    comment.likes += 1;
  }
}
