import { Post } from './postService';
import { User } from './userService';

export interface SearchResult {
  posts: Post[];
  users: User[];
}

const MOCK_POSTS: Post[] = [
  {
    id: 'p1',
    userId: 'u1',
    userName: 'Aung Kyaw',
    userAvatar: 'https://i.pravatar.cc/150?img=12',
    content: 'Beautiful sunset in Yangon 🌅',
    timestamp: Date.now() - 3600000,
    likes: 45,
    comments: 8,
    shares: 3,
    isLiked: false,
  },
];

const MOCK_USERS: User[] = [
  {
    id: 'u1',
    name: 'Aung Kyaw',
    avatar: 'https://i.pravatar.cc/150?img=12',
    bio: 'Software Developer from Yangon',
    friendCount: 342,
    isOnline: true,
    isFriend: true,
  },
  {
    id: 'u4',
    name: 'May Thu',
    avatar: 'https://i.pravatar.cc/150?img=23',
    bio: 'Travel blogger',
    friendCount: 234,
    isOnline: true,
    isFriend: false,
  },
];

export async function search(query: string): Promise<SearchResult> {
  await new Promise(resolve => setTimeout(resolve, 500));
  
  if (!query.trim()) {
    return { posts: [], users: [] };
  }
  
  const lowerQuery = query.toLowerCase();
  
  const filteredPosts = MOCK_POSTS.filter(post => 
    post.content.toLowerCase().includes(lowerQuery) ||
    post.userName.toLowerCase().includes(lowerQuery)
  );
  
  const filteredUsers = MOCK_USERS.filter(user =>
    user.name.toLowerCase().includes(lowerQuery) ||
    user.bio?.toLowerCase().includes(lowerQuery)
  );
  
  return {
    posts: filteredPosts,
    users: filteredUsers,
  };
}
