export interface Conversation {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  lastMessage: string;
  timestamp: number;
  unread: boolean;
  isOnline: boolean;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  content: string;
  timestamp: number;
  isOwn: boolean;
}

const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv1',
    userId: 'u1',
    userName: 'Aung Kyaw',
    userAvatar: 'https://i.pravatar.cc/150?img=12',
    lastMessage: 'See you tomorrow! 👋',
    timestamp: Date.now() - 300000,
    unread: true,
    isOnline: true,
  },
  {
    id: 'conv2',
    userId: 'u2',
    userName: 'Thida San',
    userAvatar: 'https://i.pravatar.cc/150?img=45',
    lastMessage: 'Thanks for the help!',
    timestamp: Date.now() - 3600000,
    unread: false,
    isOnline: false,
  },
  {
    id: 'conv3',
    userId: 'u3',
    userName: 'Kyaw Min',
    userAvatar: 'https://i.pravatar.cc/150?img=33',
    lastMessage: 'Let me know when you are free',
    timestamp: Date.now() - 7200000,
    unread: true,
    isOnline: true,
  },
];

const MOCK_MESSAGES: Message[] = [
  {
    id: 'm1',
    conversationId: 'conv1',
    senderId: 'u1',
    content: 'Hey! How are you?',
    timestamp: Date.now() - 600000,
    isOwn: false,
  },
  {
    id: 'm2',
    conversationId: 'conv1',
    senderId: 'current',
    content: "I'm good! Thanks for asking 😊",
    timestamp: Date.now() - 450000,
    isOwn: true,
  },
  {
    id: 'm3',
    conversationId: 'conv1',
    senderId: 'u1',
    content: 'See you tomorrow! 👋',
    timestamp: Date.now() - 300000,
    isOwn: false,
  },
];

export async function getConversations(): Promise<Conversation[]> {
  await new Promise(resolve => setTimeout(resolve, 300));
  return MOCK_CONVERSATIONS;
}

export async function getMessages(conversationId: string): Promise<Message[]> {
  await new Promise(resolve => setTimeout(resolve, 300));
  return MOCK_MESSAGES.filter(m => m.conversationId === conversationId);
}

export async function sendMessage(conversationId: string, content: string): Promise<Message> {
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const newMessage: Message = {
    id: `m${Date.now()}`,
    conversationId,
    senderId: 'current',
    content,
    timestamp: Date.now(),
    isOwn: true,
  };
  
  MOCK_MESSAGES.push(newMessage);
  return newMessage;
}
